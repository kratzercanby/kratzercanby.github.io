Hello Guys

First of all Thanks for downloading the eBook!
We have a few things to share with you :)

++++++++++++++++++++++++
Free eBooks & Tutorials
++++++++++++++++++++++++

+----------------------------------------------------------------------------------------------------------+

1. Anybody is free to share/repost our books but must include this NFO file (We hope you guys have atleast that much respect for us) :)

+----------------------------------------------------------------------------------------------------------+

2. Do not download our books if you think it breaks the Law of Copyright. Buy the book instead. The aim is to help people, mainly students, who cannot afford to buy the costly books from the market.

+----------------------------------------------------------------------------------------------------------+

3. If you like our work & want something to do for our blog then you can help us in the following ways:

	a. Share our blog www.PlentyofeBooks.net which now have Torrents
	b. Seed our Torrents
	c. Donate Us through our blog :)

--------------------

With Best Regards
www.PlentyofeBooks.net